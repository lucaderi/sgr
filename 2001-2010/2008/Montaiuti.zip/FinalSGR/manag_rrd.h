#include <rrd.h>
#include <pthread.h>

#include "iwtan_data.h"
#include "iwtan_analyze.h"

/* Permission rules of AP and STATION's directory */
#define MODE_DIR 0777
/**
step time for metrics upgrades
*/
#define STEP_TIME_LITTLE 5
#define STEP_TIME_BIG 10
/**
maximum wait time for metrics upgrades
*/
#define HEART_BEAT_LITTLE 5
#define HEART_BEAT_BIG 10
/**
maximum number of elements for rrd variable
*/
#define RRA_ROWS 5000

/**
structure for managment control
@param mtx mutex for access to iwtan_context
@param cond wait condition for access to iwtan_context
@param context structure containing all the iwtan's data
@param flag	flag for synchronization between the two threads
@param broadcast counter of broadcast packets
*/
typedef struct {
	pthread_mutex_t mtx;
	pthread_cond_t cond;
	iwtan_context *context;
	unsigned int flag;
	unsigned int *broadcast;
}manag_control;

/** 
create an AP directory and the rrd files
@param apMac	the AP mac address 
*/
void create_ap(mac_address apMac);

/**
 create a STATION directory and the rrd files
@param apMac	the Station mac address
*/
void create_sta(mac_address apMac);

/**
 create a file rrd  
@param	filename	name of rrd file 
*/
void create_rrd_file(char* filename);

/**
 Read the new values to the IWTAN structure and update the rrd files of the AP
@param	ap	the IWTAN structure that represents an AP 
@param broadcast	counter of broadcast packets 
*/
void update_ap_rrd(iwtan_ap* ap,unsigned long broadcast);

/** 
Read the new values to the IWTAN structure and update the rrd files of the Station
@param	sta	the IWTAN structure that represents a Station
@param	broadcast	counter of broadcast packets	
*/
void update_sta_rrd(iwtan_station* sta,unsigned long broadcast);

/** 
 Search the mac_address. If mac exist, the current directory will be changed to mac's directory
@param add	the mac address 
@return 0 if exists, -1 otherwise
*/
int mac_exist(mac_address add);
/**
 check the structures at regular times and create directories and files for metrics of AP and Station
@param control	pointer to a manag_control structure 
*/
void man_rrd_file(void* control);
