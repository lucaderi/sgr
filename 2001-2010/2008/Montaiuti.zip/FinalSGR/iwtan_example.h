
#include "iwtan_data.h"
#include "iwtan_analyze.h"
#include "manag_rrd.h"	

#include <pcap.h>
#include <stdlib.h>
#include <sys/socket.h>


#include <stdio.h>
#define _GNU_SOURCE
#include <getopt.h>
#include <iwlib.h>
#include <signal.h>
#include <time.h>


int main (int argc, char** argv);
void end(int sig);
char** parseArgs(int argc, char**argv);

