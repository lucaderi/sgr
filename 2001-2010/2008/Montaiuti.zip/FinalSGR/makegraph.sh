#!/bin/bash

cd AP
end_time=$(date +%H:%M)
start=$1


for file in $(command ls -aF | grep "/") ; do

	if [ "$file" ] && [ "$file" != "./" ] && [ "$file" != "../" ]; then
	cd $file

	sudo rrdtool graph sent.png DEF:Sent=sent_byte.rrd:SentByte:LAST AREA:Sent#ff0000:'SENT' -s $start -e $end_time -t "Sent Bytes" -v Bytes  -E -i -W CORNOLTI-GENOVESE-MARZINI-MONTAUTI

	sudo rrdtool graph received.png DEF:Recev=received_byte.rrd:ReceByte:LAST AREA:Recev#ff0000:'REC' -s $start -e $end_time -t "Received Bytes" -v Byte  -E -i -W CORNOLTI-GENOVESE-MARZINI-MONTAUTI

	sudo rrdtool graph ipv4pack.png DEF:ipv4=ipv4_pack.rrd:ipv4Pack:LAST AREA:ipv4#ff0000:'IPV4 PACK' -s $start -e $end_time -t "Ipv4 Packets Received" -v Packets -E -i -W CORNOLTI-GENOVESE-MARZINI-MONTAUTI	

	sudo rrdtool graph ipv6pack.png DEF:ipv6=ipv6_pack.rrd:ipv6Pack:LAST AREA:ipv6#ff0000:'IPV6 PACK' -s $start -e $end_time -t "Ipv6 Packets Received" -v Packets -E -i -W CORNOLTI-GENOVESE-MARZINI-MONTAUTI

	sudo rrdtool graph sentPack.png DEF:SentPack=sent_pack.rrd:SentPack:LAST AREA:SentPack#ff0000:'SENT PACK' -s $start -e $end_time -t "Sent Packets" -v Packets -E -i -W CORNOLTI-GENOVESE-MARZINI-MONTAUTI
	
	sudo rrdtool graph assNum.png DEF:AssociaN=assoc_num.rrd:AssociaN:LAST AREA:AssociaN#ff0000:'NUM ASSOCIATION' -s $start -e $end_time -t "Number of associations" -v Associations -E -i -W CORNOLTI-GENOVESE-MARZINI-MONTAUTI

	sudo rrdtool graph signpow.png DEF:SignalPo=signal_pow.rrd:SignalPo:LAST AREA:SignalPo#ff0000:'SIGNAL POWER' -s $start -e $end_time -t "Signal power" -v db -E -i -W CORNOLTI-GENOVESE-MARZINI-MONTAUTI

	sudo rrdtool graph attem.png DEF:AttemFau=fault_attempts.rrd:AttemFau:LAST DEF:AttemSuc=succ_attempts.rrd:AttemSuc:LAST LINE:AttemFau#ff0000:'ATTEMP FAULT' LINE:AttemSuc#ff00ff:'ATTEMP SUCC ' -s $start -e $end_time  -v Number -t "Attempt"  -E -i -W CORNOLTI-GENOVESE-MARZINI-MONTAUTI

	cd ..
	fi
done

cd ..

cd STATION

for file2 in $(command ls -aF | grep "/") ; do
	if [ "$file2" ] && [ "$file2" != "./" ] && [ "$file2" != "../" ]; then
	cd $file2

	sudo rrdtool graph sent.png DEF:Sent=sent_byte.rrd:SentByte:LAST AREA:Sent#ff0000:'SENT' -s $start -e $end_time -t "Sent Bytes" -v Bytes -E -i -W CORNOLTI-GENOVESE-MARZINI-MONTAUTI

	sudo rrdtool graph received.png DEF:Rece=received_byte.rrd:ReceByte:LAST AREA:Rece#ff0000:'REC' -s $start -e $end_time -t "Received Bytes" -v Byte -E -i -W CORNOLTI-GENOVESE-MARZINI-MONTAUTI

	sudo rrdtool graph copy.png DEF:Copy=copy_pack.rrd:CopyPack:LAST AREA:Copy#ff0000:'COPY PACK' -s $start -e $end_time -t "Number of retransmitted packets" -v Packets -E -i -W CORNOLTI-GENOVESE-MARZINI-MONTAUTI

	cd ..
	fi

done

cd ..