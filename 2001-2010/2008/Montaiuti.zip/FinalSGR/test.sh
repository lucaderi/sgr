#!/bin/bash

START_TIME=$(date +%H:%M)
sudo iwconfig eth1 mode monitor
sudo ifconfig eth1 up
sudo ./iwtan_example -d eth1
sudo ./makegraph.sh $START_TIME
sudo ./make_web
firefox index.html &
