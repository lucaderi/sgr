<?php
//controlla che l'indirizzo ip passato non sia privato.
function validateIP($ip){
	if (substr($ip,0,(strpos($ip,"."))) == "0") return FALSE;
	if (substr($ip,0,(strpos($ip,"."))) == "10") return FALSE;
	if (substr($ip,0,(strpos($ip,"."))) == "127") return FALSE;
	if (substr($ip,0,(strpos($ip,"."))) == "224") return FALSE;
	if (substr($ip,0,(strpos($ip,"."))) == "240") return FALSE;
	if (substr($ip,0,(strpos($ip,".",strpos($ip,".")+1))) == "169.254") return FALSE;
	if (substr($ip,0,(strpos($ip,".",strpos($ip,".")+1))) == "172.16") return FALSE;
	if (substr($ip,0,(strpos($ip,".",strpos($ip,".")+1))) == "192.168") return FALSE;
	if (substr($ip,0,(strpos($ip,".",strpos($ip,".")+1))) == "198.18") return FALSE;
	return TRUE;
}
$ip_arr = array();
//Funzione che interroga il database per trovare gli indirizzi ip
function db($ip_arr){
	$i = 0;
	$righa = array();	
	$return = array();		
	//Parametri necessari per la connessione al database
	$server   = 'localhost'; // MySQL hostname
	$username = 'root'; // MySQL username
	$password = ''; // MySQL password
	$dbname   = 'iptonation'; // MySQL db name
	$db = mysql_connect($server, $username, $password) or die(mysql_error());
	mysql_select_db($dbname) or die(mysql_error());

	//Eseguo una serie di richeste al database per rintracciare le  coordinate dei vari indirizzi ip
	while ($i < count($ip_arr) ){
		if (validateIP($ip_arr[$i])){
		$sql = "SELECT c.country, c.lat, c.lon
	        FROM ip2nationCountries c, ip2nation i 
	        WHERE i.ip < INET_ATON(\"$ip_arr[$i]\") AND c.code = i.country 
	        ORDER BY i.ip DESC 
	        LIMIT 0,1";
		$risultato = mysql_query($sql);
		//il risultato della query viene inserito nell'array righa
		$righa[$i] = mysql_fetch_array($risultato, MYSQL_NUM);
		}
		$i++;
	}
	$i = 0;
	//Riempie l'array per la stampa raggruppando gli host per nazione
	while ($i < count($righa)){ //per ogni query
	    $rig = $righa[$i]; //rig: array indicizzato per nazione contiene al suo interno le coordinate e un contatore
		if (($rig[1] != "") && ($rig[2] != "")){ //controllo che le coordinate fornite dal database non siano nulle
		if(array_key_exists($rig[0],$return)){ $return[$rig[0]][2]++; } //aumento il contatore se la nazione è già stata inserita nell'arrray
		else{ $return[$rig[0]]= array ($rig[1],$rig[2],1); } //aggiungo un elemento nel vettoore in caso contrario
		}
		$i++;
	}
	return $return;
}


//Questa funzione prende l'array passato dalla funzione "db" e stampa il suo contenuto.
function stampadb($return){ 
//Le funzioni "createmarker", "focuson", "load" e "reload" sono codice javascript generato da php necessario per caricare la pagina e stampare i marker.
    echo ("
		<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"
		\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
		<html xmlns=\"http://www.w3.org/1999/xhtml\">
		<head>
		<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\"/>
		<title>Geo Location per Nazione</title>

		<script src=\"http://maps.google.com/maps?file=api&amp;v=2&amp;key=$apikey\" type=\"text/javascript\"></script>
	
		<script type=\"text/javascript\">
	
		var markers = new Array();
		var infos = new Array();

		function createMarker(point, label, color) 
		{
			icona = new GIcon();
			var immagine = new Array();
			immagine[0]=\"Rosso/Rosso1.png\";
			immagine[1]=\"Rosso/Rosso2.png\";
			immagine[2]=\"Rosso/Rosso3.png\";
			immagine[3]=\"Rosso/Rosso4.png\";
			immagine[4]=\"Rosso/Rosso5.png\";
			if(color <= 4){ icona.image = immagine[color]; }
			else{ icona.image = immagine[4];}
			icona.iconSize = new GSize(20, 20);
			icona.iconAnchor = new GPoint(0, 20);
			icona.infoWindowAnchor = new GPoint(20, 1);
			var marker = new GMarker(point,icona);
			GEvent.addListener(marker, \"click\", function(){marker.openInfoWindowHtml(label);});
			return marker;
		}
		function load() {
  			if (GBrowserIsCompatible()) {
				var map = new GMap2(document.getElementById(\"map\"));
       				map.setCenter(new GLatLng(30,10), 2);
				map.addControl(new GLargeMapControl());
				map.addControl(new GMapTypeControl());");
	$i=0; 
	//Crea e stampa i marker della mappa
	foreach (array_keys($return) as $chia){
	//prende le informazioni necessarie dal vettore passato per parametro e le stampa (il colore dipende dal contatore)
	$r = $return[$chia];
	echo("\ninfos[$i] = \"Country: <em>$chia</em><br>Latitude: <em>$r[0]</em><br>Longitude: <em>$r[1]</em><br>Count: <em>$r[2]</em>\";");	
	echo("\nlatlng = new GLatLng($r[0],$r[1]);");
	echo("\nmarkers[$i] = new createMarker(latlng,infos[$i],$r[2]);");	
	echo("\nmap.addOverlay(markers[$i]);");
	$i++;
	}
	echo("}}
		function focusOn(index){
			markers[index].openInfoWindowHtml(infos[index]);
		}  
		function reload(){
			location.href = \"geolocation.php?i=\" + document.getElementById(\"metodo\").value;
		}
		</script>
		<link rel=\"stylesheet\" type=\"text/css\"href=\"stile.css\" />
		</head>
		<body onload=\"load()\" onunload=\"GUnload()\" class=\"pagina\">
		<div id=\"map\" class=\"map\" ></div>
		<div id=\"lista\" class=\"lista\" >");
	//stampa la colonna laterale
	$i=0;
	foreach (array_keys($return) as $chia){
	    $r = $return[$chia];
	    if($i%2 == 0){ echo("<div class=\"p1\" onclick=\"focusOn($i)\"><b>$chia [$r[2]]</b></div>"); }   
	    else{ echo("<div class=\"p2\" onclick=\"focusOn($i)\"><b>$chia [$r[2]]</b></div>"); }
        $i++;
    }
	echo(" 
		</div> 
		<div align=\"right\">
		<form action=\"geolocation.php?i=0\" method=\"GET\">
		<p><em>Visualizza per : </em><select name=\"metodo\" id=\"metodo\" onChange=\"reload()\">
		<option></option>		
		<option>Nazione</option>
		<option>Host</option>
		</select></p></form></div></body> </html> ");
}

function caida($ind_ip){
	//Creo l'array senza ripetizioni di indirizzi ip
	$ipcount = array();
	for ( $i = 0 ; $i < count($ind_ip) ; $i++ ){
	    if(validateIP($ind_ip[$i])){
	    $chiave = $ind_ip[$i];
	    if(array_key_exists($chiave, $ipcount)){ $ipcount[$chiave]++; }
	    else{ $ipcount[$chiave] = 1; }
    }}
    //Parametri per la connessione a caida
	$host="netgeo.caida.org" ; 
	$target="/perl/netgeo.cgi?target=" ; 
	$port=80 ; 
	$timeout=60;    
        
    //Ottengo le informazioni relative all'indirizzo ip tramite caida
	foreach ( array_keys($ipcount) as $ind ){
	    //Creazione della socket verso caida, invio richiesta e ricezione risposta, 
	    $sk=fsockopen($host,$port,$errnum,$errstr,$timeout) ;
	    if(!is_resource($sk)){ exit("Connessione fallita: ".$errnum." ".$errstr); }
        else{
             fputs ($sk, "GET $target".$ind."\r\n"); 
	         $dati="" ; 
	         while (!feof($sk)){ $dati.= fgets ($sk,2048); } 
        }
	    fclose($sk);
	    //Inserisco i dati acquisiti in un array indicizzato con l'indirizzo IP
	    $info["ip"] = $ind;
        $dati3 = stristr($dati,"name");
	    $info["name"] = substr($dati3,stripos($dati3, "name")+10,stripos($dati3, "<b")-10);
	    $info["name"] = trim($info["name"]);    
	    $dati4 = stristr($dati,"city");
	    $info["city"] = substr($dati4,stripos($dati4, "city")+10,stripos($dati4, "<b")-10);
	    $info["city"] = trim($info["city"]);
        $dati5 = stristr($dati,"state");
        $info["state"] = substr($dati5,stripos($dati5, "state")+10,stripos($dati5, "<b")-10);
	    $info["state"] = trim($info["state"]);
        $dati6 = stristr($dati,"country");
        $info["country"] = substr($dati6,stripos($dati6, "country")+10,stripos($dati6, "<b")-10);
	    $info["country"] = trim($info["country"]);
        $dati7 = stristr($dati,"lat");
        $info["lat"] = substr($dati7,stripos($dati7, "lat")+10,stripos($dati7, "<b")-10);
        $info["lat"] = trim($info["lat"]);
        $dati8 = stristr($dati,"long");
        $info["long"] = substr($dati8,stripos($dati8, "long")+10,stripos($dati8, "<b")-10);
	    $info["long"] = trim($info["long"]);
        $info["counter"] = $ipcount[$ind];
        $ipcount[$ind] = $info;
	}
    return $ipcount;
}


//Questa funzione è analoga alla precedente "stampadb" se non per il contenuto informativo dell'array passato per parametro leggermente differente.
	function stampacaida($return){
		echo ("
		<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"
		\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
		<html xmlns=\"http://www.w3.org/1999/xhtml\">
		<head>
		<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\"/>
		<title>Geo Location per Host</title>

		<script src=\"http://maps.google.com/maps?file=api&amp;v=2&amp;key=$apikey\" type=\"text/javascript\"></script>
	
		<script type=\"text/javascript\">
	
		var markers = new Array();
		var infos = new Array();

		function createMarker(point, label, color) 
		{
			icona = new GIcon();
			var immagine = new Array();
			immagine[0]=\"Rosso/Rosso1.png\";
			immagine[1]=\"Rosso/Rosso2.png\";
			immagine[2]=\"Rosso/Rosso3.png\";
			immagine[3]=\"Rosso/Rosso4.png\";
			immagine[4]=\"Rosso/Rosso5.png\";
			if(color <= 4){ icona.image = immagine[color]; }
			else{ icona.image = immagine[4];}
			icona.iconSize = new GSize(20, 20);
			icona.iconAnchor = new GPoint(0, 20);
			icona.infoWindowAnchor = new GPoint(20, 1);
			var marker = new GMarker(point,icona);
			GEvent.addListener(marker, \"click\", function(){marker.openInfoWindowHtml(label);});
			return marker;
		}
		function load() {
  			if (GBrowserIsCompatible()) {
				var map = new GMap2(document.getElementById(\"map\"));
       				map.setCenter(new GLatLng(30,10), 2);
				map.addControl(new GLargeMapControl());
				map.addControl(new GMapTypeControl());");
		$i=0; 
		//Crea e stampa i marker della mappa
		foreach (array_keys($return) as $chia){
			$r = $return[$chia];
			echo("\ninfos[$i] = \"Target: <em>$chia</em><br>Name: <em>".$r['name']."</em><br>Country: <em>".$r['country']."</em><br>State: <em>".$r['state']."</em><br>City: <em>".$r['city']."</em><br>Latitude: <em>".$r['lat']."</em><br>Longitude: <em>".$r['long']."</em><br>Count: <em>".$r['counter']."</em>\";");
			echo("\nlatlng = new GLatLng(".$r['lat'].",".$r['long'].");");
			echo("\nmarkers[$i] = new createMarker(latlng,infos[$i],".$r['counter'].");");
			echo("\nmap.addOverlay(markers[$i]);");
			$i++;
		}
		echo("}}
		function focusOn(index){
			markers[index].openInfoWindowHtml(infos[index]);
		}  
		function reload(index){
			location.href = \"geolocation.php?i=\" + document.getElementById(\"metodo\").value;
		}
		</script>
		<link rel=\"stylesheet\" type=\"text/css\"href=\"stile.css\" />
		</head>
		<body onload=\"load()\" onunload=\"GUnload()\" class=\"pagina\">
		<div id=\"map\" class=\"map\" ></div>
		<div id=\"lista\" class=\"lista\" >");
		$i=0;
		foreach (array_keys($return) as $chia){
			$r = $return[$chia];
			if($i%2 == 0){
				echo("<div class=\"p1\" onclick=\"focusOn($i)\"><b>$chia [".$r['counter']."]</b></div>");
			}else{
				echo("<div class=\"p2\" onclick=\"focusOn($i)\"><b>$chia [".$r['counter']."]</b></div>");
			}
			$i++;
		}
		echo(" 
		</div> 
		<div align=\"right\">
		<form action=\"geolocation.php?i=0\" method=\"GET\">
		<p><em>Visualizza per : </em><select name=\"metodo\" id=\"metodo\" onChange=\"reload()\">
		<option></option>
		<option>Nazione</option>
		<option>Host</option>
		</select></p></form></div></body> </html> "); 
	}
    //Codice di controllo e apertura dei file apikey e ip.
	if (!$p_file = fopen("apikey.txt","r")) {
		echo "Errore Apertura File Apikey...";
	}else{
		$apikey = fgets($p_file, 255);
		if($apikey == ""){
			echo("Errore Lettura Apikey...");
		}
		fclose($p_file);
	}
	
	if (!$p_file = fopen("ip.txt","r")) {
		echo "Errore Apertura File IP...";
	} else {
		$k=0;
		while(!feof($p_file))
		{
			$singleip = fgets($p_file, 255);
			$singleip = str_replace(chr(13), "",$singleip);
			$singleip = str_replace(chr(10), "",$singleip);
			if($singleip != ""){
				$ip_arr[$k] = $singleip;
				$k++;			
			}
		}
		fclose($p_file);
	}
	if($_GET['i'] == "Nazione"){stampadb(db($ip_arr));}
	else if($_GET['i'] == "Host"){stampacaida(caida($ip_arr));}
	else{stampadb(db($ip_arr));}
?>
