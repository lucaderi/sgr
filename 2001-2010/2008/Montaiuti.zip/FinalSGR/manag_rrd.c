#include "manag_rrd.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h> 
#include <dirent.h>
#include <iwlib.h>



/* create the AP directory and the rrd file*/
void create_ap(mac_address apMac){
	
	char** buffer=malloc(2*sizeof(char*));
	char* macBuf = calloc(18,sizeof(char));
	
	ether_ntoa_r(&apMac, macBuf);
	mkdir(macBuf,MODE_DIR);
	chdir(macBuf);
	free(macBuf);
	
	
	
	buffer[0]=calloc(1,100);
	buffer[1]=calloc(1,100);
	
	int status;
	
	/* create the metric of AP */
	sprintf(buffer[0],"DS:SentByte:COUNTER:%d:0:%u",HEART_BEAT_LITTLE,ULONG_MAX);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("sent_byte.rrd",STEP_TIME_LITTLE,time(NULL)-10,2,buffer);
	if(status!=0)
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer[0],"DS:ReceByte:COUNTER:%d:0:%u",HEART_BEAT_LITTLE,ULONG_MAX);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("received_byte.rrd",STEP_TIME_LITTLE,time(NULL)-10,2,buffer);
	if(status!=0)
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer[0],"DS:ipv4Pack:COUNTER:%d:0:%u",HEART_BEAT_LITTLE,ULONG_MAX);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("ipv4_pack.rrd",STEP_TIME_LITTLE,time(NULL)-10,2,buffer);
	if(status!=0)
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer[0],"DS:ipv6Pack:COUNTER:%d:0:%u",HEART_BEAT_LITTLE,ULONG_MAX);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("ipv6_pack.rrd",STEP_TIME_LITTLE,time(NULL)-10,2,buffer);
	if(status!=0)
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer[0],"DS:SentPack:COUNTER:%d:0:%u",HEART_BEAT_LITTLE,ULONG_MAX);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("sent_pack.rrd",STEP_TIME_LITTLE,time(NULL)-10,2,buffer);
	if(status!=0)
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer[0],"DS:AssociaN:GAUGE:%d:0:%d",HEART_BEAT_BIG,USHRT_MAX);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("assoc_num.rrd",STEP_TIME_BIG,time(NULL)-10,2,buffer);
	if(status!=0)	
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer[0],"DS:SignalPo:GAUGE:%d:0:%d",HEART_BEAT_BIG,100);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("signal_pow.rrd",STEP_TIME_BIG,time(NULL)-10,2,buffer);
	if(status!=0)
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer[0],"DS:AttemFau:COUNTER:%d:0:%d",HEART_BEAT_BIG,USHRT_MAX);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("fault_attempts.rrd",STEP_TIME_BIG,time(NULL)-10,2,buffer);
	if(status!=0)
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer[0],"DS:AttemSuc:COUNTER:%d:0:%d",HEART_BEAT_BIG,USHRT_MAX);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("succ_attempts.rrd",STEP_TIME_BIG,time(NULL)-10,2,buffer);
	if(status!=0)
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	
	chdir("..");
	free(buffer[0]);
	free(buffer[1]);

}
/* create the STATION directory and the rrd file*/
 void create_sta(mac_address staMac){
	
	char* macBuf = calloc(18,sizeof(char));
	char** buffer=malloc(2*sizeof(char*));
	
	ether_ntoa_r(&staMac, macBuf);
	mkdir(macBuf,MODE_DIR);
	chdir(macBuf);
	

	free(macBuf);
	
	
	buffer[0]=calloc(1,100);
	buffer[1]=calloc(1,100);
	int status=0;
	/* create the metric of STATION */
	
	sprintf(buffer[0],"DS:SentByte:COUNTER:%d:0:%u",5,ULONG_MAX);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("sent_byte.rrd",5,time(NULL)-10,2,buffer);
	if(status!=0)
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer[0],"DS:ReceByte:COUNTER:%d:0:%u",5,ULONG_MAX);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("received_byte.rrd",5,time(NULL)-10,2,buffer);
	if(status!=0)
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer[0],"DS:CopyPack:COUNTER:%d:0:%u",5,UINT_MAX);
	sprintf(buffer[1],"RRA:LAST:0.5:1:%d",RRA_ROWS);
	status=rrd_create_r("copy_pack.rrd",5,time(NULL)-10,2,buffer);
	if(status!=0)
		printf("error create: %s\n return: %d\n",rrd_get_error(),status);
	
	chdir("..");
	free(buffer[0]);
	free(buffer[1]);
}


/* Read the new values to the IWTAN structure and update the rrd files of the AP*/
void update_ap_rrd(iwtan_ap* ap, unsigned long broadcast){
	
	char* apMacBuf = calloc(18,sizeof(char));
	char * buffer;

	
	int status;
	/* open the directory where are stored the AP's rrd_files */
	chdir(ether_ntoa_r(ap->bssId, apMacBuf));
	free(apMacBuf);	


	buffer=calloc(1,50);

	sprintf(buffer,"N:%u",ap->associations);
	status=rrd_update_r("assoc_num.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);
		
	sprintf(buffer,"N:%u",ap->infoT->sent_byte);

	status=rrd_update_r("sent_byte.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer,"N:%u",ap->infoT->received_byte+broadcast);

	status=rrd_update_r("received_byte.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer,"N:%u",ap->infoT->ipv4_pack);

	status=rrd_update_r("ipv4_pack.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer,"N:%u",ap->infoT->ipv6_pack);

	status=rrd_update_r("ipv6_pack.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer,"N:%u",ap->infoT->sent_pack);

	status=rrd_update_r("sent_pack.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);

	
	sprintf(buffer,"N:%u",ap->signal);

	status=rrd_update_r("signal_pow.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);


	sprintf(buffer,"N:%u",(ap->infoT->total_attempts)-(ap->infoT->success_attempts));

	status=rrd_update_r("fault_attempts.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer,"N:%u",ap->infoT->success_attempts);

	status=rrd_update_r("succ_attempts.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);

	free(buffer);
	chdir("..");
}

/* Read the new values to the IWTAN structure and update the rrd files of the Station*/
void update_sta_rrd(iwtan_station* sta, unsigned long broadcast){
	
	char* stMacBuf = calloc(18,sizeof(char));
	char* buffer;
	int status;
	/* open the directory where are stored the station's rrd_files */
	chdir(ether_ntoa_r(sta->mac, stMacBuf));
	free(stMacBuf);
	buffer=calloc(1,50);

	sprintf(buffer,"N:%u",sta->infoT->sent_byte);
	status=rrd_update_r("sent_byte.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);

	sprintf(buffer,"N:%u",sta->infoT->received_byte+broadcast);
	status=rrd_update_r("received_byte.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);
	
	sprintf(buffer,"N:%d",sta->infoT->copy_pack);
	status=rrd_update_r("copy_pack.rrd", NULL, 1, &buffer);
	if(status!=0)
		printf("error update: %s\n return: %d\n",rrd_get_error(),status);
	
	free(buffer);
	chdir("..");
}

/* Search the mac_address. If mac exist, the current directory will be changed to mac's directory */
int mac_exist(mac_address add){
	
	char* macBuf = calloc(18,sizeof(char));
	
	/* mac not exist */
	if (chdir(ether_ntoa_r(&add, macBuf))==-1 && errno==ENOENT)
	{
		free(macBuf);
		return -1;
	}
	/* mac exist */
	free(macBuf);
	return 0;
}

void man_rrd_file(void* control) {
	manag_control *ctr=(manag_control *)control;
	iwtan_context* context=ctr->context;
	
	iwtan_station_el* init_sta_list=NULL;
	iwtan_station_el* sta_list=NULL;
	iwtan_station* sta=NULL;
	
	iwtan_ap_el* init_ap_list=NULL;
	iwtan_ap_el* ap_list=NULL;
	iwtan_ap* ap=NULL;

	int broadcast;
	
	mkdir("AP",MODE_DIR);
	mkdir("./STATION",MODE_DIR);
	

	while(1)	
	{
		
		pthread_mutex_lock(&(ctr->mtx));
		while(!(ctr->flag)) pthread_cond_wait(&(ctr->cond),&(ctr->mtx));
		init_sta_list = iwtan_get_all_stations(context);
		init_ap_list = iwtan_get_all_APs(context);
		if(init_ap_list!=NULL)
		{
			ap_list=init_ap_list;
			ap=init_ap_list->ap;
		}
		if(init_sta_list!=NULL)
		{
			sta_list=init_sta_list;
			sta=init_sta_list->station;
		}
		

		/* AP */
		chdir("./AP");
		while(ap!=NULL)
		{
			if(mac_exist(*(ap->bssId))!=0)
				create_ap(*(ap->bssId));
			update_ap_rrd(ap,context->broadcastTraffic);
			ap_list=ap_list->next;
			if(ap_list!=NULL)
				ap=ap_list->ap;
			else 
				ap=NULL;
		}
		
		chdir("..");
		
		chdir("./STATION");
		char* macBuf ;
		/* STATION */
		while(sta!=NULL)
		{
			macBuf = calloc(18,sizeof(char));
			ether_ntoa_r(sta->mac, macBuf);
			if(mac_exist(*(sta->mac))!=0)
				create_sta(*(sta->mac));	
			update_sta_rrd(sta,context->broadcastTraffic);
			sta_list=sta_list->next;
			if(sta_list!=NULL)
				sta=sta_list->station;
			else
				sta=NULL;	
		}
		chdir("..");
		ctr->flag=0;
		pthread_mutex_unlock(&ctr->mtx);
	}
}
