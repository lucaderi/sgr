#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <glob.h>


/**
	Stampa tutti i files con una determinata estensione in un file html
\param path pathname della cartella in cui cercare i files
\param format estensione del file 
*/
void print_all_files(char *path,char *format){
	glob_t matches;
	int status=0;
	char *pattern=calloc(1,strlen(format)+3);
	FILE *f=NULL;
	char *str=NULL;
	char *text=NULL;
	int i=0;
	chdir(path);
	strncpy(pattern,"*.",2);
	strcat(pattern,format);
	status=glob(pattern,GLOB_NOSORT,NULL,&matches);
	if(status!=0) {
		fprintf(stderr,"Errore durante la ricerca dei file con il formato specificato\n");
		globfree(&matches);
		chdir("..");
		return ;
	}
	/* Serializzazione su file html */
	str=calloc(1,strlen(path)+7);
	strncpy(str,path,strlen(path)+1);
	strcat(str,".html");
	f=fopen(str,"w+");
	text=calloc(1,100);
	strcpy(text,"<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01//EN\">\n");
	fwrite(text,1,strlen(text)+1,f);
	free(text);
	text=NULL;
	text=calloc(1,50);
	strcpy(text,"<html>\n<head>\n\t<title>Metrics for ");
	strcat(text,path);
	fwrite(text,1,strlen(text)+1,f);
	free(text);
	text=NULL;
	text=calloc(1,300);
	strcat(text,"</title>\n</head>\n<body><p>Metrics for \n");
	strcat(text,path);
	strcat(text,"</p>\n");
	fwrite(text,1,strlen(text)+1,f);
	free(text);
	text=NULL;
	for(i=0;i<matches.gl_pathc;i++){
		text=calloc(1,1000);
		strcpy(text,"\t<img src=\"");
		strcat(text,matches.gl_pathv[i]);
		strcat(text,"\" align=\"top\">\n");
		fwrite(text,1,strlen(text)+1,f);
		free(text);
		text=NULL;
	}
	free(str);
	free(pattern);
	text=NULL;
	fclose(f);
	globfree(&matches);
}


/** Crea un frame contenente le argc entries creando le rispettive pagine html
\param type tipo del frame: stations-frame.html o aps-frame.html
\param entries lista delle entry (stazioni o AP)
\param argc numero di entries
\param back pagina precedente  */
void make_frame_page(char *type,char **entries,int argc,char *back){
	FILE *f=NULL;
	int i=0;
	char *text=NULL;
	f=fopen(type,"w+");
	text=malloc(1000);
	strcpy(text,"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Frameset//IT\"\"http://www.w3.org/TR/html4/frameset.dtd\">\n<html>\n<head>\n\t<title>");



	if(!strcmp(type,"stations-frame.html")) {
		strcat(text,"Stations founds</title>");
	}
	else {
		strcat(text,"AccessPoint founds</title>");
	}
	strcat(text,"\n</head>\n<body>\n");

	fwrite(text,1,strlen(text)+1,f);
	free(text);
	text=NULL;

	for(i=0;i<argc;i++){
		text=malloc(1000);
		if(!strcmp(type,"stations-frame.html")) strcpy(text,"\t<p align=left>\n\t<a href=\"");
		else strcpy(text,"\t<p align=left>\n\t<a href=\"");
		strcat(text,entries[i]);
		strcat(text,"/");
		strcat(text,entries[i]);
		strcat(text,".html\" target=\"contenuto\" align=\"center\">");
		strncat(text,entries[i],strlen(entries[i]));
		strcat(text,"</a>\n\t</p>\n</body>\n</html>\n");
		fwrite(text,1,strlen(text)+1,f);
		free(text);
		text=NULL;
		print_all_files(entries[i],"png");
		chdir("..");
	}
	text=malloc(1000);
	strcpy(text,"\t<p align=center>\n\t<a href=\"");
	strcat(text,back);
	strcat(text,"\" target=\"_self\" align=\"left\">Back</a>\n\t</p>\n</body>\n</html>\n");
	fwrite(text,1,strlen(text)+1,f);
	free(text);
	fclose(f);
	chdir("..");
}
/** Crea la pagina principale
*/
void make_index(){
	char *str="<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Frameset//IT\"\"http://www.w3.org/TR/html4/frameset.dtd\">\n<html>\n<head>\n	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\n<title>IWTAN</title>\n</head>\n<frameset rows=\"20%,*\">\n<frame name=\"IWTAN\" id=\"intestazione\" src=\"intestazione.html\">\n<frameset cols=\"20%,*\">\n<frame name=\"Graphs\" id=\"Graphs\" src=\"menu.html\">\n<frame name=\"contenuto\" id=\"contenuto\" src=\"iwtan_reference.htm\">\n</frameset>\n</frameset>\n</frameset>\n</html>";
	FILE *f=fopen("index.html","w+");
	fwrite(str,1,strlen(str)+1,f);
	str=NULL;
	f=fopen("menu.html","w+");
	str="<html>\n<head>\n<title>menu</title>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\n</head>\n<body>\n<A href=\"STATION/stations-frame.html\">Stations</a>\n<p></p>\n<A href=\"AP/aps-frame.html\">Access Point</a>\n</body>\n</html>\n";
	fwrite(str,1,strlen(str)+1,f);
	fclose(f);
}
	/** Crea tutte le pagine web relative alle stationi e gli access point rilevati da IWTAN.
	Per ogni elemento viene create una pagina web con i grafici relativi alle metriche raccolte.
*/
int main(){
	int i,j,k=0;
	char **sta_list=NULL;
	char **ap_list=NULL;
 	struct dirent **namelist;
        int n=0;
	make_index();
	chdir("AP");
	sta_list=calloc(100,sizeof(char*));
	ap_list=calloc(100,sizeof(char*));
        n = scandir(".", &namelist, 0, alphasort);
        if (n < 0)
               perror("scandir");
	else if(n==0) make_frame_page("aps-frame.html",NULL,0,"../menu.html");
        else {
               while (n--) {
			if(namelist[n]->d_type==DT_DIR && strcmp(namelist[n]->d_name,".") && strcmp(namelist[n]->d_name,"..")){
				ap_list[k]=malloc(18*sizeof(char));
                   		strcpy(ap_list[k], namelist[n]->d_name);
				k++;
              		 }
		}
		make_frame_page("aps-frame.html",ap_list,k,"../menu.html");
        }
	for(j=0;j<k;j++) free(ap_list[j]);
	free(ap_list);
	chdir("STATION");
	free(namelist);
	n = scandir(".", &namelist, 0, alphasort);
	k=0;
        if (n < 0)
               perror("scandir");
	else if(n==0) make_frame_page("stations-frame.html",NULL,0,"../menu.html");
        else {
               while (n--) {
			if(namelist[n]->d_type==DT_DIR && strcmp(namelist[n]->d_name,".") && strcmp(namelist[n]->d_name,"..")){
				sta_list[k]=malloc(18*sizeof(char));
	                   	strcpy(sta_list[k], namelist[n]->d_name);
				k++;
               		}
		}
		make_frame_page("stations-frame.html",sta_list,k,"../menu.html");
        }
	for(j=0;j<k;j++) free(sta_list[j]);
	free(sta_list);
	free(namelist);
return 0;
}
